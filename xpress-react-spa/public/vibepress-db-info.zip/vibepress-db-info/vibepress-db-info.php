<?php
/**
 * Plugin Name:       Vibepress
 * Description:       Kết nối WordPress với Vibepress Platform — tự động sync lên GitHub.
 * Version:           3.2.0
 * Requires at least: 6.0
 * Tested up to:      6.7
 * Requires PHP:      8.0
 * Author:            Vibepress Team
 * License:           GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

// -------------------------------------------------------
// CONSTANTS
// -------------------------------------------------------
define( 'VPDB_BACKEND_URL',             'http://xpress.aihubproduction.com:5000' );
define( 'VPDB_OPTION_API_KEY',          'vpdb_api_key' );      // set SAU KHI register thành công — dùng cho vpdb_is_connected()
define( 'VPDB_OPTION_USER_API_KEY',     'vpdb_user_api_key' ); // input của user trong settings form
define( 'VPDB_OPTION_BACKEND_URL',      'vpdb_backend_url' );
define( 'VPDB_OPTION_GH_REPO',          'vpdb_gh_repo' );
define( 'VPDB_OPTION_WEBHOOK_ID',       'vpdb_webhook_id' );
define( 'VPDB_OPTION_WEBHOOK_SEC',      'vpdb_webhook_secret' );
define( 'VPDB_OPTION_CONNECTED_AT',     'vpdb_connected_at' );
define( 'VPDB_OPTION_LAST_SYNC',        'vpdb_last_sync' );
define( 'VPDB_OPTION_ERROR',            'vpdb_error' );
define( 'VPDB_OPTION_IS_FIRST_CONNECT', 'vpdb_is_first_connect' );
define( 'VPDB_TRANSIENT_GH_TOKEN',      'vpdb_gh_token' );

// -------------------------------------------------------
// HELPERS
// -------------------------------------------------------
function vpdb_is_connected(): bool {
	return ! empty( get_option( VPDB_OPTION_API_KEY ) );
}

function vpdb_get_webhook_url(): string {
	return rtrim( get_site_url(), '/' ) . '/wp-json/vibepress/v1/github-webhook';
}


function vpdb_gh_headers(): array {
	return [
		'Authorization'        => 'Bearer ' . vpdb_get_github_token(),
		'Accept'               => 'application/vnd.github+json',
		'X-GitHub-Api-Version' => '2022-11-28',
		'Content-Type'         => 'application/json',
		'User-Agent'           => 'Vibepress-Plugin',
	];
}

// -------------------------------------------------------
// GITHUB TOKEN — cache transient, xin lại khi hết hạn
// -------------------------------------------------------
function vpdb_get_github_token(): ?string {
	$cached = get_transient( VPDB_TRANSIENT_GH_TOKEN );
	if ( $cached ) return $cached;

	$backend_url = VPDB_BACKEND_URL;
	$api_key     = get_option( VPDB_OPTION_API_KEY, '' );
	if ( empty( $api_key ) ) return null;

	$response = wp_remote_post( $backend_url . '/api/wp/get-token', [
		'timeout' => 15,
		'headers' => [
			'Content-Type'    => 'application/json',
			'X-Vibepress-Key' => $api_key,
		],
		'body' => wp_json_encode( [ 'siteUrl' => get_site_url() ] ),
	] );

	if ( is_wp_error( $response ) ) return null;

	$body  = json_decode( wp_remote_retrieve_body( $response ), true );
	$token = $body['githubToken'] ?? null;

	if ( $token ) {
		set_transient( VPDB_TRANSIENT_GH_TOKEN, $token, 55 * MINUTE_IN_SECONDS );
	}

	return $token;
}

// -------------------------------------------------------
// ĐĂNG KÝ — gửi site info kèm API key, nhận githubToken + githubRepo
// -------------------------------------------------------
function vpdb_register(): bool {
	$backend_url = VPDB_BACKEND_URL;
	$api_key     = get_option( VPDB_OPTION_USER_API_KEY, '' ); // đọc từ input của user

	if ( empty( $api_key ) ) {
		update_option( VPDB_OPTION_ERROR, 'Vui lòng nhập Vibepress API Key trước khi kết nối.' );
		return false;
	}

	$response = wp_remote_post( $backend_url . '/api/wp/register', [
		'timeout' => 15,
		'headers' => [
			'Content-Type'    => 'application/json',
			'X-Vibepress-Key' => $api_key,
		],
		'body' => wp_json_encode( [
			'siteUrl'    => get_site_url(),
			'siteName'   => get_bloginfo( 'name' ),
			'wpVersion'  => get_bloginfo( 'version' ),
			'adminEmail' => get_bloginfo( 'admin_email' ),
		] ),
	] );

	if ( is_wp_error( $response ) ) {
		update_option( VPDB_OPTION_ERROR, $response->get_error_message() );
		return false;
	}

	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( empty( $body['githubToken'] ) ) {
		update_option( VPDB_OPTION_ERROR, $body['error'] ?? 'Backend không trả về githubToken' );
		return false;
	}

	// Chỉ set VPDB_OPTION_API_KEY tại đây — sau khi xác nhận backend hợp lệ
	update_option( VPDB_OPTION_API_KEY,          sanitize_text_field( $api_key ) );
	update_option( VPDB_OPTION_CONNECTED_AT,     time() );
	update_option( VPDB_OPTION_GH_REPO,          sanitize_text_field( $body['githubRepo'] ?? '' ) );
	update_option( VPDB_OPTION_ERROR,            '' );
	update_option( VPDB_OPTION_IS_FIRST_CONNECT, $body['isFirstConnect'] ?? false );
	set_transient( VPDB_TRANSIENT_GH_TOKEN, $body['githubToken'], 55 * MINUTE_IN_SECONDS );

	return true;
}

// -------------------------------------------------------
// PUSH 1 FILE LÊN GITHUB (dùng cho save_post, theme editor)
// -------------------------------------------------------
function vpdb_push_content_to_github( string $content, string $repo_path, string $message = '' ): bool {
	$token = vpdb_get_github_token();
	$repo  = get_option( VPDB_OPTION_GH_REPO, '' );
	if ( empty( $token ) || empty( $repo ) ) return false;

	$headers = vpdb_gh_headers();
	$url     = "https://api.github.com/repos/{$repo}/contents/{$repo_path}";
	$msg     = $message ?: "sync: update {$repo_path}";

	// Lấy SHA nếu file đã tồn tại
	$existing = wp_remote_get( $url, [ 'headers' => $headers, 'timeout' => 15 ] );
	$body     = [ 'message' => $msg, 'content' => base64_encode( $content ) ];

	if ( ! is_wp_error( $existing ) && wp_remote_retrieve_response_code( $existing ) === 200 ) {
		$data        = json_decode( wp_remote_retrieve_body( $existing ), true );
		$body['sha'] = $data['sha'];
	}

	$response = wp_remote_request( $url, [
		'method'  => 'PUT',
		'timeout' => 30,
		'headers' => $headers,
		'body'    => wp_json_encode( $body ),
	] );

	$code    = wp_remote_retrieve_response_code( $response );
	$success = ! is_wp_error( $response ) && in_array( $code, [ 200, 201 ] );

	if ( ! $success ) {
		$err = is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response );
		error_log( "[Vibepress] Push FAILED: {$repo_path} — HTTP {$code} — {$err}" );
	} else {
		error_log( "[Vibepress] Push OK: {$repo_path}" );
		update_option( VPDB_OPTION_LAST_SYNC, time() );
	}

	return $success;
}

function vpdb_push_files_batch( array $files, string $message ): bool {
	$token = vpdb_get_github_token();
	$repo  = get_option( VPDB_OPTION_GH_REPO, '' );

	error_log( '[Vibepress] push_files_batch — token: ' . ( $token ? 'yes' : 'NO' ) . ' repo: ' . $repo . ' files: ' . count( $files ) );

	if ( empty( $token ) || empty( $repo ) || empty( $files ) ) return false;

	$headers = vpdb_gh_headers();
	$base    = "https://api.github.com/repos/{$repo}";

	// Bước 1 — Kiểm tra repo có commit chưa, xác định branch
	$branch     = 'main';
	$latest_sha = null;
	$base_tree  = null;

	foreach ( [ 'main', 'master' ] as $b ) {
		$ref_res  = wp_remote_get( "{$base}/git/ref/heads/{$b}", [ 'headers' => $headers, 'timeout' => 15 ] );
		$ref_data = json_decode( wp_remote_retrieve_body( $ref_res ), true );
		if ( ! empty( $ref_data['object']['sha'] ) ) {
			$branch     = $b;
			$latest_sha = $ref_data['object']['sha'];
			break;
		}
	}

	error_log( '[Vibepress] branch: ' . $branch . ' latest_sha: ' . ( $latest_sha ?? 'NULL — repo empty, will init' ) );

	// Repo trống → tạo commit init trước
	if ( ! $latest_sha ) {
		error_log( '[Vibepress] Repo empty — creating init commit via Contents API' );
		$init_res = wp_remote_request( "{$base}/contents/.vibepress", [
			'method'  => 'PUT',
			'timeout' => 15,
			'headers' => $headers,
			'body'    => wp_json_encode( [
				'message' => 'init: initialize repository',
				'content' => base64_encode( '# Vibepress WP Source' ),
			] ),
		] );

		$init_code = wp_remote_retrieve_response_code( $init_res );
		error_log( '[Vibepress] init commit HTTP: ' . $init_code );

		if ( ! in_array( $init_code, [ 200, 201 ] ) ) {
			error_log( '[Vibepress] init commit FAILED: ' . wp_remote_retrieve_body( $init_res ) );
			return false;
		}

		// Lấy lại SHA sau khi init
		foreach ( [ 'main', 'master' ] as $b ) {
			$ref_res  = wp_remote_get( "{$base}/git/ref/heads/{$b}", [ 'headers' => $headers, 'timeout' => 15 ] );
			$ref_data = json_decode( wp_remote_retrieve_body( $ref_res ), true );
			if ( ! empty( $ref_data['object']['sha'] ) ) {
				$branch     = $b;
				$latest_sha = $ref_data['object']['sha'];
				break;
			}
		}

		error_log( '[Vibepress] after init — branch: ' . $branch . ' sha: ' . ( $latest_sha ?? 'STILL NULL' ) );
		if ( ! $latest_sha ) return false;
	}

	// Bước 2 — Lấy base tree từ commit hiện tại
	$commit_res = wp_remote_get( "{$base}/git/commits/{$latest_sha}", [ 'headers' => $headers, 'timeout' => 15 ] );
	if ( is_wp_error( $commit_res ) ) return false;
	$base_tree = json_decode( wp_remote_retrieve_body( $commit_res ), true )['tree']['sha'] ?? null;
	if ( ! $base_tree ) return false;

	// Bước 3 — Chia files thành chunks 50, mỗi chunk tạo 1 tree + 1 commit
	// Text files: inline content (không cần tạo blob riêng)
	// Binary files: tạo blob với base64 trước
	$binary_extensions = [ 'webp', 'woff2', 'png', 'jpg', 'jpeg', 'gif', 'ico', 'eot', 'ttf', 'otf', 'woff' ];
	$chunks            = array_chunk( $files, 50, true );
	$total_chunks      = count( $chunks );

	foreach ( $chunks as $chunk_index => $chunk_files ) {
		$tree_items = [];
		foreach ( $chunk_files as $repo_path => $content ) {
			$ext = strtolower( pathinfo( $repo_path, PATHINFO_EXTENSION ) );
			if ( in_array( $ext, $binary_extensions ) ) {
				$blob_res = wp_remote_post( "{$base}/git/blobs", [
					'timeout' => 30,
					'headers' => $headers,
					'body'    => wp_json_encode( [
						'content'  => base64_encode( $content ),
						'encoding' => 'base64',
					] ),
				] );
				if ( is_wp_error( $blob_res ) ) continue;
				$blob = json_decode( wp_remote_retrieve_body( $blob_res ), true );
				if ( empty( $blob['sha'] ) ) continue;
				$tree_items[] = [
					'path' => $repo_path,
					'mode' => '100644',
					'type' => 'blob',
					'sha'  => $blob['sha'],
				];
			} else {
				$tree_items[] = [
					'path'    => $repo_path,
					'mode'    => '100644',
					'type'    => 'blob',
					'content' => $content,
				];
			}
		}

		if ( empty( $tree_items ) ) continue;

		$chunk_label = $total_chunks > 1 ? ' (' . ( $chunk_index + 1 ) . "/{$total_chunks})" : '';

		$tree_res = wp_remote_post( "{$base}/git/trees", [
			'timeout' => 60,
			'headers' => $headers,
			'body'    => wp_json_encode( [ 'base_tree' => $base_tree, 'tree' => $tree_items ] ),
		] );
		if ( is_wp_error( $tree_res ) ) return false;
		$new_tree = json_decode( wp_remote_retrieve_body( $tree_res ), true )['sha'] ?? null;
		if ( ! $new_tree ) return false;

		$new_commit_res = wp_remote_post( "{$base}/git/commits", [
			'timeout' => 30,
			'headers' => $headers,
			'body'    => wp_json_encode( [
				'message' => $message . $chunk_label,
				'tree'    => $new_tree,
				'parents' => [ $latest_sha ],
			] ),
		] );
		if ( is_wp_error( $new_commit_res ) ) return false;
		$new_sha = json_decode( wp_remote_retrieve_body( $new_commit_res ), true )['sha'] ?? null;
		if ( ! $new_sha ) return false;

		$base_tree  = $new_tree;
		$latest_sha = $new_sha;
		error_log( '[Vibepress] Chunk ' . ( $chunk_index + 1 ) . "/{$total_chunks} committed: " . count( $tree_items ) . ' files' );
	}

	// Bước 4 — Update branch HEAD với commit cuối cùng
	$update_res = wp_remote_request( "{$base}/git/refs/heads/{$branch}", [
		'method'  => 'PATCH',
		'timeout' => 30,
		'headers' => $headers,
		'body'    => wp_json_encode( [ 'sha' => $latest_sha ] ),
	] );

	$code    = wp_remote_retrieve_response_code( $update_res );
	$success = ! is_wp_error( $update_res ) && $code === 200;

	if ( $success ) {
		update_option( VPDB_OPTION_LAST_SYNC, time() );
		error_log( '[Vibepress] Batch OK: ' . count( $files ) . ' files in ' . $total_chunks . ' chunk(s) → branch ' . $branch );
	} else {
		error_log( '[Vibepress] Batch FAIL update ref HTTP ' . $code . ': ' . wp_remote_retrieve_body( $update_res ) );
	}
	return $success;
}

// -------------------------------------------------------
// XÓA TOÀN BỘ FILES DƯỚI 1 PREFIX TRÊN GITHUB → 1 COMMIT
// -------------------------------------------------------
function vpdb_delete_github_tree( string $prefix, string $message ): bool {
	$token = vpdb_get_github_token();
	$repo  = get_option( VPDB_OPTION_GH_REPO, '' );
	if ( empty( $token ) || empty( $repo ) ) return false;

	$headers = vpdb_gh_headers();
	$base    = "https://api.github.com/repos/{$repo}";

	// Xác định branch và SHA hiện tại
	$branch     = 'main';
	$latest_sha = null;
	foreach ( [ 'main', 'master' ] as $b ) {
		$ref_res  = wp_remote_get( "{$base}/git/ref/heads/{$b}", [ 'headers' => $headers, 'timeout' => 15 ] );
		$ref_data = json_decode( wp_remote_retrieve_body( $ref_res ), true );
		if ( ! empty( $ref_data['object']['sha'] ) ) {
			$branch     = $b;
			$latest_sha = $ref_data['object']['sha'];
			break;
		}
	}
	if ( ! $latest_sha ) return false;

	// Lấy tree SHA từ commit hiện tại
	$commit_res = wp_remote_get( "{$base}/git/commits/{$latest_sha}", [ 'headers' => $headers, 'timeout' => 15 ] );
	$base_tree  = json_decode( wp_remote_retrieve_body( $commit_res ), true )['tree']['sha'] ?? null;
	if ( ! $base_tree ) return false;

	// Fetch toàn bộ tree đệ quy để tìm files cần xóa
	$tree_res  = wp_remote_get( "{$base}/git/trees/{$base_tree}?recursive=1", [ 'headers' => $headers, 'timeout' => 30 ] );
	$all_items = json_decode( wp_remote_retrieve_body( $tree_res ), true )['tree'] ?? [];

	$to_delete = [];
	foreach ( $all_items as $item ) {
		if ( $item['type'] !== 'blob' ) continue;
		if ( str_starts_with( $item['path'], $prefix ) ) {
			$to_delete[] = [ 'path' => $item['path'], 'mode' => '100644', 'type' => 'blob', 'sha' => null ];
		}
	}

	if ( empty( $to_delete ) ) {
		error_log( "[Vibepress] delete_github_tree: no files found under {$prefix} — skip" );
		return true;
	}

	error_log( "[Vibepress] delete_github_tree: removing " . count( $to_delete ) . " files under {$prefix}" );

	// Tạo tree mới với các file bị đánh dấu xóa (sha = null)
	$new_tree_res = wp_remote_post( "{$base}/git/trees", [
		'timeout' => 60,
		'headers' => $headers,
		'body'    => wp_json_encode( [ 'base_tree' => $base_tree, 'tree' => $to_delete ] ),
	] );
	$new_tree = json_decode( wp_remote_retrieve_body( $new_tree_res ), true )['sha'] ?? null;
	if ( ! $new_tree ) return false;

	// Tạo commit xóa
	$new_commit_res = wp_remote_post( "{$base}/git/commits", [
		'timeout' => 30,
		'headers' => $headers,
		'body'    => wp_json_encode( [ 'message' => $message, 'tree' => $new_tree, 'parents' => [ $latest_sha ] ] ),
	] );
	$new_sha = json_decode( wp_remote_retrieve_body( $new_commit_res ), true )['sha'] ?? null;
	if ( ! $new_sha ) return false;

	// Cập nhật branch HEAD
	$update_res = wp_remote_request( "{$base}/git/refs/heads/{$branch}", [
		'method'  => 'PATCH',
		'timeout' => 30,
		'headers' => $headers,
		'body'    => wp_json_encode( [ 'sha' => $new_sha ] ),
	] );

	$code    = wp_remote_retrieve_response_code( $update_res );
	$success = ! is_wp_error( $update_res ) && $code === 200;

	if ( $success ) {
		error_log( "[Vibepress] delete_github_tree OK: {$prefix} — " . count( $to_delete ) . ' files removed' );
	} else {
		error_log( "[Vibepress] delete_github_tree FAIL: HTTP {$code} — " . wp_remote_retrieve_body( $update_res ) );
	}

	return $success;
}

// -------------------------------------------------------
// SYNC TOÀN BỘ THEMES → 1 COMMIT
// -------------------------------------------------------
function vpdb_sync_theme_bg( bool $sync_plugins = true, string $old_stylesheet = '' ): void {
	set_time_limit( 0 );
	error_log( '[Vibepress] vpdb_sync_theme_bg started' );

	// Xóa theme cũ khỏi GitHub trước khi push theme mới
	if ( $old_stylesheet ) {
		error_log( "[Vibepress] Removing old theme from GitHub: themes/{$old_stylesheet}/" );
		vpdb_delete_github_tree(
			"themes/{$old_stylesheet}/",
			"sync: remove old theme {$old_stylesheet}"
		);
	}

	$stylesheet = get_stylesheet();
	$all_themes = [ $stylesheet => wp_get_theme( $stylesheet ) ];
	$files      = [];

	foreach ( $all_themes as $stylesheet => $theme ) {
		$theme_dir = $theme->get_stylesheet_directory();
		if ( ! is_dir( $theme_dir ) ) continue;

		$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $theme_dir ) );
		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) continue;
			$allowed_extensions = [ 'php', 'css', 'js', 'html', 'webp', 'woff2' , 'png', 'jpg', 'jpeg' , 'woff' ];
			$is_theme_json      = $file->getExtension() === 'json' && $file->getFilename() === 'theme.json';
			if ( ! in_array( $file->getExtension(), $allowed_extensions ) && ! $is_theme_json ) continue;
			$repo_path           = 'themes/' . $stylesheet . '/' . ltrim( str_replace( $theme_dir, '', $file->getPathname() ), '/\\' );
			$files[ $repo_path ] = file_get_contents( $file->getPathname() );
		}
	}

	error_log( '[Vibepress] Total files to push: ' . count( $files ) );

	$success = vpdb_push_files_batch( $files, 'sync: initial upload — ' . count( $files ) . ' files' );

	error_log( '[Vibepress] vpdb_push_files_batch result: ' . ( $success ? 'OK' : 'FAIL' ) );

	if ( $sync_plugins ) {
		vpdb_sync_spectra_plugin();
	}
	// Báo backend
	$backend_url = VPDB_BACKEND_URL;
	$api_key     = get_option( VPDB_OPTION_API_KEY, '' );

	wp_remote_post( $backend_url . '/api/wp/sync-complete', [
		'timeout' => 15,
		'headers' => [
			'Content-Type'    => 'application/json',
			'X-Vibepress-Key' => $api_key,
		],
		'body' => wp_json_encode( [
			'siteUrl'     => get_site_url(),
			'repoName'    => get_option( VPDB_OPTION_GH_REPO, '' ),
			'activeTheme' => $stylesheet,
			'synced'      => count( $files ),
			'success'     => $success,
			'syncedAt'    => current_time( 'c' ),
		] ),
	] );

	// Khi đổi theme, trigger backend re-dump toàn bộ DB với data của theme mới
	// (wp_options.stylesheet, theme_mods, wp_template, wp_global_styles đều thay đổi)
	if ( $old_stylesheet ) {
		error_log( "[Vibepress] Triggering DB re-sync after theme switch ({$old_stylesheet} → {$stylesheet})" );
		wp_remote_post( $backend_url . '/api/wp/trigger-db-sync', [
			'timeout'  => 5,
			'blocking' => false,
			'headers'  => [
				'Content-Type'    => 'application/json',
				'X-Vibepress-Key' => $api_key,
			],
			'body' => wp_json_encode( [ 'siteUrl' => get_site_url() ] ),
		] );
	}
}

add_action( 'vpdb_sync_theme_bg', 'vpdb_sync_theme_bg' );

// -------------------------------------------------------
// SYNC SPECTRA PLUGIN (Ultimate Addons for Gutenberg) → 1 COMMIT
// Push source code của Spectra lên GitHub để AI đọc được cách
// các block (slider, modal, post-carousel, ...) render ra HTML/CSS.
// -------------------------------------------------------
function vpdb_sync_spectra_plugin(): void {
	// Thử cả slug free lẫn pro — lấy cái đầu tiên tồn tại
	$candidate_slugs = [ 'ultimate-addons-for-gutenberg', 'spectra-pro' ];
	$spectra_slug    = null;
	$spectra_dir     = null;
	foreach ( $candidate_slugs as $slug ) {
		$dir = WP_PLUGIN_DIR . '/' . $slug;
		if ( is_dir( $dir ) ) {
			$spectra_slug = $slug;
			$spectra_dir  = $dir;
			break;
		}
	}

	if ( ! $spectra_dir ) {
		error_log( '[Vibepress] Spectra plugin not found, skip spectra sync' );
		return;
	}

	error_log( "[Vibepress] vpdb_sync_spectra_plugin started — slug: {$spectra_slug}" );

	// Chỉ lấy file có ý nghĩa cho AI đọc để gen code
	// (bỏ binary / language / vendor để giữ repo gọn)
	$allowed   = [ 'php', 'css', 'js', 'json', 'scss', 'html' ];
	$skip_dirs = [ 'node_modules', 'vendor', '.git', 'tests', 'bin', 'languages', '.github' ];

	$files    = [];
	$iterator = new RecursiveIteratorIterator(
		new RecursiveCallbackFilterIterator(
			new RecursiveDirectoryIterator( $spectra_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			function ( $file ) use ( $skip_dirs ) {
				if ( $file->isDir() ) {
					return ! in_array( $file->getFilename(), $skip_dirs, true );
				}
				return true;
			}
		)
	);

	foreach ( $iterator as $file ) {
		if ( ! $file->isFile() ) continue;
		if ( ! in_array( strtolower( $file->getExtension() ), $allowed, true ) ) continue;

		$relative            = ltrim( str_replace( $spectra_dir, '', $file->getPathname() ), '/\\' );
		$repo_path           = "plugins/{$spectra_slug}/" . str_replace( '\\', '/', $relative );
		$files[ $repo_path ] = file_get_contents( $file->getPathname() );
	}

	error_log( '[Vibepress] Spectra files to push: ' . count( $files ) );

	if ( ! empty( $files ) ) {
		vpdb_push_files_batch( $files, "sync: spectra ({$spectra_slug}) — " . count( $files ) . ' files' );
	}
}

// -------------------------------------------------------
// AUTO SYNC — WP thay đổi → commit GitHub
// -------------------------------------------------------

// Khi save post / page / template
// -------------------------------------------------------
// NOTIFY BACKEND — incremental DB sync khi content thay đổi
// Gọi non-blocking (blocking=false) để không làm chậm save.
// -------------------------------------------------------
function vpdb_notify_content_change( int $post_id, string $action = 'update' ): void {
	$backend_url = VPDB_BACKEND_URL;
	$api_key     = get_option( VPDB_OPTION_API_KEY, '' );
	if ( empty( $api_key ) ) return;

	wp_remote_post( $backend_url . '/api/wp/notify-content-change', [
		'timeout'  => 1,
		'blocking' => false,
		'headers'  => [
			'Content-Type'    => 'application/json',
			'X-Vibepress-Key' => $api_key,
		],
		'body' => wp_json_encode( [
			'siteUrl' => get_site_url(),
			'postId'  => $post_id,
			'action'  => $action,
		] ),
	] );
}

// -------------------------------------------------------
// NOTIFY BACKEND — incremental sync khi comment thay đổi
// -------------------------------------------------------
function vpdb_notify_comment_change( int $comment_id, string $action = 'update' ): void {
	$backend_url = VPDB_BACKEND_URL;
	$api_key     = get_option( VPDB_OPTION_API_KEY, '' );
	if ( empty( $api_key ) ) return;

	wp_remote_post( $backend_url . '/api/wp/notify-comment-change', [
		'timeout'  => 1,
		'blocking' => false,
		'headers'  => [
			'Content-Type'    => 'application/json',
			'X-Vibepress-Key' => $api_key,
		],
		'body' => wp_json_encode( [
			'siteUrl'   => get_site_url(),
			'commentId' => $comment_id,
			'action'    => $action,
		] ),
	] );
}

// Khi thêm comment mới (kể cả pending chờ duyệt)
add_action( 'wp_insert_comment', function ( int $comment_id ) {
	if ( ! vpdb_is_connected() ) return;
	vpdb_notify_comment_change( $comment_id, 'create' );
} );

// Khi sửa comment
add_action( 'edit_comment', function ( int $comment_id ) {
	if ( ! vpdb_is_connected() ) return;
	vpdb_notify_comment_change( $comment_id, 'update' );
} );

// Khi đổi trạng thái comment (approve, unapprove, spam, trash)
add_action( 'wp_set_comment_status', function ( int $comment_id, string $status ) {
	if ( ! vpdb_is_connected() ) return;
	$action = in_array( $status, [ 'delete', 'trash' ], true ) ? 'delete' : 'update';
	vpdb_notify_comment_change( $comment_id, $action );
}, 10, 2 );

// Khi xóa vĩnh viễn comment
add_action( 'deleted_comment', function ( int $comment_id ) {
	if ( ! vpdb_is_connected() ) return;
	vpdb_notify_comment_change( $comment_id, 'delete' );
} );

// Chỉ sync wp_template / wp_template_part lên GitHub — đây là source code theme.
// Post, page, product → không lên GitHub, thay vào đó notify backend sync DB.
add_action( 'save_post', function ( int $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( wp_is_post_revision( $post_id ) ) return;
	if ( ! vpdb_is_connected() ) return;

	$post = get_post( $post_id );
	if ( ! in_array( $post->post_status, [ 'publish', 'private' ], true ) ) return;

	$transient_key = 'vpdb_debounce_' . $post_id;
	if ( get_transient( $transient_key ) ) return;
	set_transient( $transient_key, 1, 5 );

	if ( in_array( $post->post_type, [ 'wp_template', 'wp_template_part' ], true ) ) {
		// Source code theme → lên GitHub
		if ( empty( $post->post_name ) || empty( trim( $post->post_content ) ) ) return;
		$stylesheet = wp_get_theme()->get_stylesheet();
		$repo_path  = $post->post_type === 'wp_template'
			? "themes/{$stylesheet}/templates/{$post->post_name}.html"
			: "themes/{$stylesheet}/parts/{$post->post_name}.html";
		vpdb_push_content_to_github(
			$post->post_content,
			$repo_path,
			"sync: update {$post->post_type} \"{$post->post_title}\""
		);
	} else {
		// Content (post / page / product / ...) → notify backend sync DB
		vpdb_notify_content_change( $post_id, 'update' );
	}
}, 10, 1 );

// Khi chuyển post/page/product vào trash → notify backend xóa khỏi DB
add_action( 'wp_trash_post', function ( int $post_id ) {
	if ( ! vpdb_is_connected() ) return;
	$post = get_post( $post_id );
	if ( ! $post || in_array( $post->post_type, [ 'wp_template', 'wp_template_part', 'revision' ], true ) ) return;
	vpdb_notify_content_change( $post_id, 'delete' );
} );

// Khi khôi phục post từ trash → notify backend tạo lại
add_action( 'untrashed_post', function ( int $post_id ) {
	if ( ! vpdb_is_connected() ) return;
	$post = get_post( $post_id );
	if ( ! $post || in_array( $post->post_type, [ 'wp_template', 'wp_template_part', 'revision' ], true ) ) return;
	vpdb_notify_content_change( $post_id, 'create' );
} );

// Khi save file qua Theme Editor
add_action( 'wp_ajax_edit-theme-plugin-file', function () {
	if ( ! current_user_can( 'edit_themes' ) ) return;

	add_action( 'shutdown', function () {
		if ( empty( $_POST['file'] ) || empty( $_POST['theme'] ) ) return;

		$theme_root = realpath( get_theme_root() );
		$theme_slug = sanitize_file_name( $_POST['theme'] );
		$theme_dir  = realpath( $theme_root . '/' . $theme_slug );

		if ( ! $theme_dir || ! str_starts_with( $theme_dir, $theme_root ) ) return;

		$raw_file  = sanitize_text_field( $_POST['file'] );
		$file_path = realpath( $theme_dir . '/' . $raw_file );

		if ( ! $file_path || ! str_starts_with( $file_path, $theme_dir ) ) {
			error_log( "[Vibepress] Path traversal blocked: {$raw_file}" );
			return;
		}

		$repo_path = 'themes/' . $theme_slug . '/' . ltrim( str_replace( $theme_dir, '', $file_path ), '/\\' );
		vpdb_push_content_to_github(
			file_get_contents( $file_path ),
			$repo_path,
			"sync: edit theme file {$raw_file}"
		);
	} );
}, 1 );

// Khi switch theme — chạy sync ngay trong shutdown thay vì dùng WP-Cron
// (WP-Cron trên local dev không có traffic nên không tự kích hoạt được)
add_action( 'switch_theme', function ( string $new_name, WP_Theme $new_theme, WP_Theme $old_theme ) {
	if ( ! vpdb_is_connected() ) return;
	$old_stylesheet = $old_theme->get_stylesheet();
	add_action( 'shutdown', function () use ( $old_stylesheet ) {
		vpdb_sync_theme_bg( false, $old_stylesheet );
	} );
}, 10, 3 );

// -------------------------------------------------------
// GITHUB WEBHOOK — tạo / xóa tự động
// -------------------------------------------------------
function vpdb_create_github_webhook(): bool {
	$token          = vpdb_get_github_token();
	$repo           = get_option( VPDB_OPTION_GH_REPO, '' );
	$webhook_secret = wp_generate_password( 32, false );
	if ( empty( $token ) || empty( $repo ) ) return false;

	vpdb_delete_github_webhook();

	$response = wp_remote_post( "https://api.github.com/repos/{$repo}/hooks", [
		'timeout' => 15,
		'headers' => vpdb_gh_headers(),
		'body'    => wp_json_encode( [
			'name'   => 'web',
			'active' => true,
			'events' => [ 'push' ],
			'config' => [
				'url'          => vpdb_get_webhook_url(),
				'content_type' => 'json',
				'secret'       => $webhook_secret,
				'insecure_ssl' => '0',
			],
		] ),
	] );

	if ( is_wp_error( $response ) ) return false;

	$code = wp_remote_retrieve_response_code( $response );
	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $code === 201 && ! empty( $body['id'] ) ) {
		update_option( VPDB_OPTION_WEBHOOK_ID,  $body['id'] );
		update_option( VPDB_OPTION_WEBHOOK_SEC, $webhook_secret );
		error_log( '[Vibepress] Webhook created: ID=' . $body['id'] . ' URL=' . vpdb_get_webhook_url() );
		return true;
	}

	error_log( '[Vibepress] Webhook creation FAILED: HTTP ' . $code . ' — ' . wp_remote_retrieve_body( $response ) );
	return false;
}

function vpdb_delete_github_webhook(): void {
	$token      = vpdb_get_github_token();
	$repo       = get_option( VPDB_OPTION_GH_REPO, '' );
	$webhook_id = get_option( VPDB_OPTION_WEBHOOK_ID, '' );
	if ( empty( $token ) || empty( $repo ) || empty( $webhook_id ) ) return;

	wp_remote_request( "https://api.github.com/repos/{$repo}/hooks/{$webhook_id}", [
		'method'  => 'DELETE',
		'timeout' => 15,
		'headers' => vpdb_gh_headers(),
	] );

	delete_option( VPDB_OPTION_WEBHOOK_ID );
	delete_option( VPDB_OPTION_WEBHOOK_SEC );
}

// -------------------------------------------------------
// WEBHOOK — GitHub → WP
// -------------------------------------------------------
add_action( 'rest_api_init', function () {
	register_rest_route( 'vibepress/v1', '/github-webhook', [
		'methods'             => 'POST',
		'callback'            => 'vpdb_handle_github_webhook',
		'permission_callback' => '__return_true',
	] );

	// Trả về auth cookie để backend proxy fetch trang WP với quyền admin.
	// Được bảo vệ bằng API key — chỉ backend Vibepress mới được gọi.
	register_rest_route( 'vibepress/v1', '/auth-cookie', [
		'methods'             => 'GET',
		'callback'            => 'vpdb_get_auth_cookie',
		'permission_callback' => '__return_true',
	] );

	// SQL dump — danh sách tables
	register_rest_route( 'vibepress/v1', '/sql-dump/tables', [
		'methods'             => 'GET',
		'callback'            => 'vpdb_sql_dump_tables',
		'permission_callback' => '__return_true',
	] );

	// SQL dump — rows của 1 table, có phân trang
	register_rest_route( 'vibepress/v1', '/sql-dump', [
		'methods'             => 'GET',
		'callback'            => 'vpdb_sql_dump_rows',
		'permission_callback' => '__return_true',
	] );

	// Incremental sync — trả rows của wp_posts + wp_postmeta + wp_term_relationships theo post_id
	register_rest_route( 'vibepress/v1', '/post-data', [
		'methods'             => 'GET',
		'callback'            => 'vpdb_get_post_data',
		'permission_callback' => '__return_true',
	] );

	// Incremental sync — trả rows của wp_comments + wp_commentmeta theo comment_id
	register_rest_route( 'vibepress/v1', '/comment-data', [
		'methods'             => 'GET',
		'callback'            => 'vpdb_get_comment_data',
		'permission_callback' => '__return_true',
	] );
} );

// -------------------------------------------------------
// SQL DUMP — xác thực chung
// -------------------------------------------------------
function vpdb_sql_dump_auth( WP_REST_Request $request ): bool {
	$key = $request->get_header( 'X-Vibepress-Key' ) ?? $request->get_param( 'key' );
	return ! empty( $key ) && $key === get_option( VPDB_OPTION_API_KEY, '' );
}

// -------------------------------------------------------
// SQL DUMP — GET /wp-json/vibepress/v1/sql-dump/tables
// Trả về danh sách tất cả tables với row count
// -------------------------------------------------------
function vpdb_sql_dump_tables( WP_REST_Request $request ): WP_REST_Response {
	if ( ! vpdb_sql_dump_auth( $request ) ) {
		return new WP_REST_Response( [ 'error' => 'Unauthorized' ], 401 );
	}

	global $wpdb;

	$table_names = $wpdb->get_col( $wpdb->prepare(
		'SHOW TABLES LIKE %s',
		$wpdb->esc_like( $wpdb->prefix ) . '%'
	) );

	$tables = [];
	foreach ( $table_names as $name ) {
		$count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$name}`" );
		$create = $wpdb->get_row( "SHOW CREATE TABLE `{$name}`", ARRAY_N );
		$tables[] = [
			'name'   => $name,
			'rows'   => $count,
			'schema' => $create[1] ?? '',
		];
	}

	return new WP_REST_Response( [ 'tables' => $tables ], 200 );
}

// -------------------------------------------------------
// SQL DUMP — GET /wp-json/vibepress/v1/sql-dump?table=wp_posts&offset=0&limit=500
// Trả về JSON rows của 1 table, có phân trang
// -------------------------------------------------------
function vpdb_sql_dump_rows( WP_REST_Request $request ): WP_REST_Response {
	if ( ! vpdb_sql_dump_auth( $request ) ) {
		return new WP_REST_Response( [ 'error' => 'Unauthorized' ], 401 );
	}

	global $wpdb;

	$table  = sanitize_text_field( $request->get_param( 'table' ) ?? '' );
	$offset = max( 0, (int) ( $request->get_param( 'offset' ) ?? 0 ) );
	$limit  = min( 1000, max( 1, (int) ( $request->get_param( 'limit' ) ?? 500 ) ) );

	// Chỉ cho phép tables thuộc prefix của site
	$allowed = $wpdb->get_col( $wpdb->prepare(
		'SHOW TABLES LIKE %s',
		$wpdb->esc_like( $wpdb->prefix ) . '%'
	) );
	if ( ! in_array( $table, $allowed, true ) ) {
		return new WP_REST_Response( [ 'error' => 'Table not found or not allowed' ], 404 );
	}

	$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );

	// wp_options: bỏ transients (nặng, vô nghĩa với AI)
	$where = '';
	if ( $table === $wpdb->options ) {
		$where = "WHERE option_name NOT LIKE '\_transient\_%' AND option_name NOT LIKE '\_site\_transient\_%'";
	}

	$rows = $wpdb->get_results(
		"SELECT * FROM `{$table}` {$where} LIMIT {$limit} OFFSET {$offset}",
		ARRAY_A
	);

	return new WP_REST_Response( [
		'table'    => $table,
		'total'    => $total,
		'offset'   => $offset,
		'limit'    => $limit,
		'has_more' => ( $offset + $limit ) < $total,
		'rows'     => $rows,
	], 200 );
}

// -------------------------------------------------------
// INCREMENTAL SYNC — GET /wp-json/vibepress/v1/post-data?post_id=123
// Trả rows của wp_posts, wp_postmeta, wp_term_relationships theo post_id.
// Backend dùng để REPLACE INTO DB sau mỗi save_post.
// -------------------------------------------------------
function vpdb_get_post_data( WP_REST_Request $request ): WP_REST_Response {
	if ( ! vpdb_sql_dump_auth( $request ) ) {
		return new WP_REST_Response( [ 'error' => 'Unauthorized' ], 401 );
	}

	global $wpdb;

	$post_id = (int) $request->get_param( 'post_id' );
	if ( ! $post_id ) {
		return new WP_REST_Response( [ 'error' => 'post_id is required' ], 400 );
	}

	$post_row = $wpdb->get_row(
		$wpdb->prepare( "SELECT * FROM `{$wpdb->posts}` WHERE ID = %d", $post_id ),
		ARRAY_A
	);

	if ( ! $post_row ) {
		return new WP_REST_Response( [ 'error' => 'Post not found' ], 404 );
	}

	$meta_rows = $wpdb->get_results(
		$wpdb->prepare( "SELECT * FROM `{$wpdb->postmeta}` WHERE post_id = %d", $post_id ),
		ARRAY_A
	);

	$term_rows = $wpdb->get_results(
		$wpdb->prepare( "SELECT * FROM `{$wpdb->term_relationships}` WHERE object_id = %d", $post_id ),
		ARRAY_A
	);

	return new WP_REST_Response( [
		'post_id'            => $post_id,
		'posts'              => [ $post_row ],
		'postmeta'           => $meta_rows,
		'term_relationships' => $term_rows,
	], 200 );
}

// -------------------------------------------------------
// INCREMENTAL SYNC — GET /wp-json/vibepress/v1/comment-data?comment_id=123
// Trả rows của wp_comments + wp_commentmeta theo comment_id.
// Backend dùng để REPLACE INTO DB sau mỗi notify-comment-change.
// -------------------------------------------------------
function vpdb_get_comment_data( WP_REST_Request $request ): WP_REST_Response {
	if ( ! vpdb_sql_dump_auth( $request ) ) {
		return new WP_REST_Response( [ 'error' => 'Unauthorized' ], 401 );
	}

	global $wpdb;

	$comment_id = (int) $request->get_param( 'comment_id' );
	if ( ! $comment_id ) {
		return new WP_REST_Response( [ 'error' => 'comment_id is required' ], 400 );
	}

	$comment_row = $wpdb->get_row(
		$wpdb->prepare( "SELECT * FROM `{$wpdb->comments}` WHERE comment_ID = %d", $comment_id ),
		ARRAY_A
	);

	if ( ! $comment_row ) {
		return new WP_REST_Response( [ 'error' => 'Comment not found' ], 404 );
	}

	$meta_rows = $wpdb->get_results(
		$wpdb->prepare( "SELECT * FROM `{$wpdb->commentmeta}` WHERE comment_id = %d", $comment_id ),
		ARRAY_A
	);

	return new WP_REST_Response( [
		'comment_id'  => $comment_id,
		'comments'    => [ $comment_row ],
		'commentmeta' => $meta_rows,
	], 200 );
}

function vpdb_handle_github_webhook( WP_REST_Request $request ): WP_REST_Response {
	$secret    = get_option( VPDB_OPTION_WEBHOOK_SEC, '' );
	$signature = $request->get_header( 'X-Hub-Signature-256' );
	$payload   = $request->get_body();

	if ( ! empty( $secret ) ) {
		$expected = 'sha256=' . hash_hmac( 'sha256', $payload, $secret );
		if ( ! hash_equals( $expected, (string) $signature ) ) {
			return new WP_REST_Response( [ 'error' => 'Invalid signature' ], 401 );
		}
	}

	$data     = json_decode( $payload, true );
	$token    = vpdb_get_github_token();
	$repo     = get_option( VPDB_OPTION_GH_REPO, '' );
	$added    = [];
	$modified = [];
	$removed  = [];

	foreach ( $data['commits'] ?? [] as $commit ) {
		$added    = array_merge( $added,    $commit['added']    ?? [] );
		$modified = array_merge( $modified, $commit['modified'] ?? [] );
		$removed  = array_merge( $removed,  $commit['removed']  ?? [] );
	}

	foreach ( array_unique( array_merge( $added, $modified ) ) as $repo_path ) {
		vpdb_apply_file_from_github( $token, $repo, $repo_path );
	}

	foreach ( array_unique( $removed ) as $repo_path ) {
		vpdb_delete_local_file( $repo_path );
	}

	update_option( 'vpdb_last_sha', $data['after'] ?? '' );
	return new WP_REST_Response( [ 'success' => true ], 200 );
}

function vpdb_apply_file_from_github( ?string $token, string $repo, string $repo_path ): void {
	global $wpdb;
	if ( empty( $token ) ) {
		error_log( '[Vibepress] apply_file SKIP — no token' );
		return;
	}

	error_log( "[Vibepress] apply_file: {$repo_path}" );

	$response = wp_remote_get( "https://api.github.com/repos/{$repo}/contents/{$repo_path}", [
		'timeout' => 15,
		'headers' => vpdb_gh_headers(),
	] );

	if ( is_wp_error( $response ) ) {
		error_log( "[Vibepress] apply_file FAILED (wp_error): {$repo_path} — " . $response->get_error_message() );
		return;
	}

	$http_code = wp_remote_retrieve_response_code( $response );
	$data      = json_decode( wp_remote_retrieve_body( $response ), true );
	$content   = base64_decode( $data['content'] ?? '' );

	error_log( "[Vibepress] apply_file GitHub response — HTTP {$http_code}, file_sha: " . ( $data['sha'] ?? 'N/A' ) . ", size: " . ( $data['size'] ?? 0 ) . " bytes" );

	if ( $http_code !== 200 || empty( $content ) ) {
		error_log( "[Vibepress] apply_file FAILED — HTTP {$http_code}, content empty: " . ( empty( $content ) ? 'yes' : 'no' ) );
		return;
	}

	// Theme files → ghi xuống disk
	if ( str_starts_with( $repo_path, 'themes/' ) ) {
		$local = vpdb_repo_path_to_local( $repo_path );
		if ( ! $local ) {
			error_log( "[Vibepress] apply_file SKIP — cannot map to local: {$repo_path}" );
			return;
		}
		wp_mkdir_p( dirname( $local ) );
		$written = file_put_contents( $local, $content );
		if ( $written === false ) {
			error_log( "[Vibepress] apply_file WRITE FAILED (permission?): {$local}" );
			return;
		}
		if ( function_exists( 'opcache_invalidate' ) ) {
			opcache_invalidate( $local, true );
		}
		error_log( "[Vibepress] apply_file OK (disk): {$local} — {$written} bytes — preview: " . substr( $content, 0, 150 ) );

		// FSE templates/parts được lưu trong DB khi edit qua Site Editor
		// → xóa bản DB để WP fallback về file trên disk vừa ghi
		$stylesheet = wp_get_theme()->get_stylesheet();
		if ( preg_match( '#^themes/' . preg_quote( $stylesheet, '#' ) . '/templates/(.+)\.html$#', $repo_path, $m ) ) {
			$slug    = $m[1];
			$post_id = $wpdb->get_var( $wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'wp_template' LIMIT 1",
				$slug
			) );
			if ( $post_id ) {
				wp_delete_post( (int) $post_id, true );
				error_log( "[Vibepress] Deleted DB wp_template: {$slug} → WP sẽ dùng file trên disk" );
			} else {
				error_log( "[Vibepress] wp_template not in DB (file-only): {$slug}" );
			}
		}
		if ( preg_match( '#^themes/' . preg_quote( $stylesheet, '#' ) . '/parts/(.+)\.html$#', $repo_path, $m ) ) {
			$slug    = $m[1];
			$post_id = $wpdb->get_var( $wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'wp_template_part' LIMIT 1",
				$slug
			) );
			if ( $post_id ) {
				wp_delete_post( (int) $post_id, true );
				error_log( "[Vibepress] Deleted DB wp_template_part: {$slug} → WP sẽ dùng file trên disk" );
			} else {
				error_log( "[Vibepress] wp_template_part not in DB (file-only): {$slug}" );
			}
		}

		// Clear WP block template cache sau khi ghi file
		wp_cache_delete( 'wp_block_templates', 'themes' );
		wp_cache_delete( 'wp_block_template_parts', 'themes' );
		wp_clean_themes_cache();
		return;
	}

	// Posts/pages → update database
	if ( str_starts_with( $repo_path, 'content/posts/' ) || str_starts_with( $repo_path, 'content/pages/' ) ) {
		$slug      = pathinfo( $repo_path, PATHINFO_FILENAME );
		$post_type = str_starts_with( $repo_path, 'content/posts/' ) ? 'post' : 'page';
		$existing  = get_posts( [
			'name'        => $slug,
			'post_type'   => $post_type,
			'post_status' => 'any',
			'numberposts' => 1,
		] );

		if ( ! empty( $existing ) ) {
			wp_update_post( [
				'ID'           => $existing[0]->ID,
				'post_content' => $content,
			] );
			error_log( "[Vibepress] apply_file OK (DB {$post_type}): {$slug}" );
		} else {
			error_log( "[Vibepress] apply_file SKIP — {$post_type} not found: {$slug}" );
		}
	}
}

/**
 * GET /wp-json/vibepress/v1/auth-cookie
 *
 * Tự động tạo auth cookie cho admin user đầu tiên tìm được.
 * Plugin đang chạy trong WordPress nên không cần hỏi user nhập gì.
 * Cookie hết hạn sau 1 giờ — backend cache lại để tránh gọi nhiều lần.
 */
function vpdb_get_auth_cookie( WP_REST_Request $request ): WP_REST_Response {
	// Xác thực bằng API key — chỉ backend Vibepress được gọi endpoint này
	$key = $request->get_header( 'X-Vibepress-Key' ) ?? $request->get_param( 'key' );
	if ( empty( $key ) || $key !== get_option( VPDB_OPTION_API_KEY, '' ) ) {
		return new WP_REST_Response( [ 'error' => 'Unauthorized' ], 401 );
	}

	// Lấy admin user đầu tiên
	$admins = get_users( [ 'role' => 'administrator', 'number' => 1, 'fields' => [ 'ID' ] ] );
	if ( empty( $admins ) ) {
		return new WP_REST_Response( [ 'error' => 'No administrator found' ], 404 );
	}

	$user_id    = (int) $admins[0]->ID;
	$expiration = time() + HOUR_IN_SECONDS; // 1 giờ

	// Sinh cookie value — WordPress tự tính hash dựa trên user data + secret keys
	$cookie_value = wp_generate_auth_cookie( $user_id, $expiration, 'logged_in' );

	return new WP_REST_Response( [
		'cookieName'  => LOGGED_IN_COOKIE,   // vd: wordpress_logged_in_abc123
		'cookieValue' => $cookie_value,
		'expiresAt'   => $expiration,
	], 200 );
}

function vpdb_repo_path_to_local( string $repo_path ): ?string {
	$stylesheet = wp_get_theme()->get_stylesheet();
	$theme_dir  = realpath( get_theme_root() . '/' . $stylesheet );
	$prefix     = "themes/{$stylesheet}/";

	if ( ! str_starts_with( $repo_path, $prefix ) ) return null;

	$relative   = substr( $repo_path, strlen( $prefix ) );
	$local_path = $theme_dir . '/' . $relative;

	if ( ! str_starts_with( dirname( $local_path ), $theme_dir ) ) {
		error_log( "[Vibepress] Path traversal blocked: {$repo_path}" );
		return null;
	}

	return $local_path;
}

function vpdb_delete_local_file( string $repo_path ): void {
	$local = vpdb_repo_path_to_local( $repo_path );
	if ( ! $local || ! file_exists( $local ) ) return;
	if ( ! unlink( $local ) ) {
		error_log( "[Vibepress] Failed to delete: {$local}" );
	}
}

// -------------------------------------------------------
// ADMIN MENU & SETTINGS PAGE
// -------------------------------------------------------
add_action( 'admin_menu', function () {
	add_menu_page( 'Vibepress', 'Vibepress', 'manage_options', 'vibepress-db-info', 'vpdb_settings_page', 'dashicons-rest-api', 3 );
} );

add_action( 'admin_init', function () {
	register_setting( 'vpdb_settings_group', VPDB_OPTION_USER_API_KEY );
} );

function vpdb_settings_page(): void {
	$notice = null;
	$msg    = '';

	if ( isset( $_POST['vpdb_action'] ) && check_admin_referer( 'vpdb_nonce' ) ) {
		switch ( $_POST['vpdb_action'] ) {
			case 'connect':
				delete_option( VPDB_OPTION_API_KEY );
				delete_transient( VPDB_TRANSIENT_GH_TOKEN );
				$ok = vpdb_register();

				error_log( '[Vibepress] register result: ' . ( $ok ? 'OK' : 'FAIL' ) );
				error_log( '[Vibepress] isFirstConnect: ' . var_export( get_option( VPDB_OPTION_IS_FIRST_CONNECT ), true ) );
				error_log( '[Vibepress] githubRepo: ' . get_option( VPDB_OPTION_GH_REPO ) );
				error_log( '[Vibepress] githubToken exists: ' . ( get_transient( VPDB_TRANSIENT_GH_TOKEN ) ? 'yes' : 'no' ) );

				if ( $ok ) {
					vpdb_create_github_webhook();
					set_time_limit( 0 );
					ignore_user_abort( true );
					vpdb_sync_theme_bg();
					$msg = '✅ Kết nối thành công! Theme đã được sync lên GitHub.';
				}
				$notice = $ok
					? [ 'type' => 'success', 'msg' => $msg ?? '' ]
					: [ 'type' => 'error',   'msg' => '❌ ' . esc_html( get_option( VPDB_OPTION_ERROR ) ) ];
				break;

			case 'reset':
				// Xóa toàn bộ options của plugin
				$options = [
					VPDB_OPTION_API_KEY,
					VPDB_OPTION_USER_API_KEY,
					VPDB_OPTION_BACKEND_URL,
					VPDB_OPTION_GH_REPO,
					VPDB_OPTION_WEBHOOK_ID,
					VPDB_OPTION_WEBHOOK_SEC,
					VPDB_OPTION_CONNECTED_AT,
					VPDB_OPTION_LAST_SYNC,
					VPDB_OPTION_ERROR,
					VPDB_OPTION_IS_FIRST_CONNECT,
					'vpdb_last_sha',
				];
				vpdb_delete_github_webhook();
				foreach ( $options as $option ) {
					delete_option( $option );
				}
				delete_transient( VPDB_TRANSIENT_GH_TOKEN );
				$notice = [ 'type' => 'success', 'msg' => '🗑️ Đã xóa toàn bộ data của Vibepress khỏi WordPress.' ];
				break;
		}
	}

	$connected      = vpdb_is_connected();
	$api_key        = get_option( VPDB_OPTION_API_KEY, '' );       // key đã xác thực (sau connect)
	$user_api_key   = get_option( VPDB_OPTION_USER_API_KEY, '' );  // key user nhập trong form
	$connected_at = get_option( VPDB_OPTION_CONNECTED_AT );
	$last_sync    = get_option( VPDB_OPTION_LAST_SYNC );
	$gh_repo      = get_option( VPDB_OPTION_GH_REPO, '' );
	$last_error   = get_option( VPDB_OPTION_ERROR, '' );
	?>
	<style>
		@keyframes vpdb-spin { to { transform: rotate(360deg); } }
		@keyframes vpdb-pulse { 0%,100%{ opacity:1 } 50%{ opacity:.4 } }
		.vpdb-step { display:flex;align-items:center;gap:10px;padding:7px 0;font-size:13px;color:#646970;transition:color .3s }
		.vpdb-step.active { color:#2271b1;font-weight:600 }
		.vpdb-step.done { color:#00a32a }
		.vpdb-step-dot { width:10px;height:10px;border-radius:50%;background:#ddd;flex-shrink:0;transition:background .3s }
		.vpdb-step.active .vpdb-step-dot { background:#2271b1;animation:vpdb-pulse 1s ease-in-out infinite }
		.vpdb-step.done .vpdb-step-dot { background:#00a32a }
	</style>

	<div id="vpdb-loading-overlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;align-items:center;justify-content:center;">
		<div style="background:#fff;border-radius:12px;padding:36px 44px;text-align:center;min-width:320px;max-width:420px;box-shadow:0 12px 40px rgba(0,0,0,.25)">
			<div style="margin-bottom:20px">
				<svg width="44" height="44" viewBox="0 0 44 44" style="animation:vpdb-spin .9s linear infinite">
					<circle cx="22" cy="22" r="18" fill="none" stroke="#e0e0e0" stroke-width="4"/>
					<path d="M22 4 A18 18 0 0 1 40 22" fill="none" stroke="#2271b1" stroke-width="4" stroke-linecap="round"/>
				</svg>
			</div>
			<div id="vpdb-loading-title" style="font-size:17px;font-weight:700;color:#1d2327;margin-bottom:6px">Đang kết nối...</div>
			<div id="vpdb-loading-sub" style="font-size:13px;color:#646970;margin-bottom:24px;min-height:36px">Đang xác thực API Key với Vibepress</div>
			<div style="text-align:left;border-top:1px solid #f0f0f0;padding-top:16px">
				<div class="vpdb-step active" id="vpdb-step-1"><span class="vpdb-step-dot"></span> Xác thực &amp; đăng ký site</div>
				<div class="vpdb-step" id="vpdb-step-2"><span class="vpdb-step-dot"></span> Tạo GitHub webhook</div>
				<div class="vpdb-step" id="vpdb-step-3"><span class="vpdb-step-dot"></span> Upload theme lên GitHub</div>
				<div class="vpdb-step" id="vpdb-step-4"><span class="vpdb-step-dot"></span> Sync DB</div>
			</div>
			<div style="margin-top:18px;font-size:11px;color:#aaa">Quá trình này có thể mất 1–3 phút</div>
		</div>
	</div>

	<div class="wrap">
		<h1>Vibepress</h1>

		<?php if ( $notice ) : ?>
			<div class="notice notice-<?php echo esc_attr( $notice['type'] ); ?> is-dismissible">
				<p><?php echo esc_html( $notice['msg'] ); ?></p>
			</div>
		<?php endif; ?>

		<?php if ( $connected ) : ?>
			<div style="background:#f0fff4;padding:14px 18px;border-radius:6px;border-left:4px solid #00a32a;margin-bottom:20px">
				<strong>✅ Đã kết nối</strong><br>
				API Key: <code><?php echo esc_html( substr( $api_key, 0, 8 ) . '••••••••••' ); ?></code>
				&nbsp;|&nbsp; Repo: <code><?php echo esc_html( $gh_repo ); ?></code><br>
				<?php if ( $connected_at ) : ?>
					Kết nối: <strong><?php echo esc_html( human_time_diff( $connected_at ) . ' trước' ); ?></strong>
				<?php endif; ?>
				<?php if ( $last_sync ) : ?>
					&nbsp;|&nbsp; Sync gần nhất: <strong><?php echo esc_html( human_time_diff( $last_sync ) . ' trước' ); ?></strong>
				<?php endif; ?>
				<br><small style="color:#555">GitHub Token cache tạm thời — không lưu vĩnh viễn.</small>
			</div>
		<?php else : ?>
			<div style="background:#fff8f0;padding:14px 18px;border-radius:6px;border-left:4px solid #dba617;margin-bottom:20px">
				<strong>⚠️ Chưa kết nối</strong> — Nhập Backend URL và nhấn Kết nối.
				<?php if ( $last_error ) : ?>
					<br><span style="color:#c00"><?php echo esc_html( $last_error ); ?></span>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<form method="post" action="options.php">
			<?php settings_fields( 'vpdb_settings_group' ); ?>
			<table class="form-table">
				<tr>
					<th><label for="vpdb_user_api_key">Vibepress API Key</label></th>
					<td>
						<input type="text" id="vpdb_user_api_key" name="<?php echo VPDB_OPTION_USER_API_KEY; ?>"
							class="regular-text" value="<?php echo esc_attr( $user_api_key ); ?>"
							placeholder="vp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" />
						<p class="description">Lấy API Key từ trang tài khoản Vibepress của bạn, sau đó nhấn <strong>Kết nối</strong>.</p>
					</td>
				</tr>
			</table>
			<?php submit_button( 'Lưu cài đặt', 'secondary small' ); ?>
		</form>

		<hr>

		<h2><?php echo $connected ? 'Kết nối lại' : 'Kết nối với Vibepress'; ?></h2>

		<form id="vpdb-connect-form" method="post" style="display:inline-block;margin-right:8px">
			<?php wp_nonce_field( 'vpdb_nonce' ); ?>
			<input type="hidden" name="vpdb_action" value="connect">
			<?php submit_button( $connected ? '🔁 Kết nối lại' : '🔗 Kết nối với Vibepress', $connected ? 'secondary' : 'primary', 'submit', false ); ?>
		</form>

		<hr>
		<h2>Reset</h2>
		<p style="color:#c00">Xóa toàn bộ data Vibepress khỏi WordPress database (API Key, Repo, Webhook...). Không ảnh hưởng đến GitHub repo.</p>
		<form method="post">
			<?php wp_nonce_field( 'vpdb_nonce' ); ?>
			<input type="hidden" name="vpdb_action" value="reset">
			<?php submit_button( '🗑️ Reset toàn bộ data', 'delete small', 'submit', false ); ?>
		</form>
	</div>

	<script>
	(function () {
		var form    = document.getElementById('vpdb-connect-form');
		var overlay = document.getElementById('vpdb-loading-overlay');
		if (!form || !overlay) return;

		form.addEventListener('submit', function () {
			overlay.style.display = 'flex';

			var title = document.getElementById('vpdb-loading-title');
			var sub   = document.getElementById('vpdb-loading-sub');

			function setStep(id) {
				['1','2','3','4'].forEach(function(n) {
					var el = document.getElementById('vpdb-step-' + n);
					if (!el) return;
					var num = parseInt(n);
					var cur = parseInt(id);
					el.className = 'vpdb-step' + (num < cur ? ' done' : num === cur ? ' active' : '');
				});
			}

			var steps = [
				{ t: 0,     step: 1, title: 'Đang kết nối...',              sub: 'Đang xác thực API Key với Vibepress backend' },
				{ t: 4000,  step: 2, title: 'Đang tạo webhook...',           sub: 'Thiết lập GitHub webhook để nhận sự kiện push' },
				{ t: 8000,  step: 3, title: 'Đang upload theme lên GitHub...', sub: 'Có thể mất vài phút nếu theme có nhiều file' },
				{ t: 40000, step: 3, title: 'Vẫn đang upload...',            sub: 'Theme lớn — vui lòng đợi thêm' },
				{ t: 90000, step: 4, title: 'Đang sync database...',         sub: 'Backend đang dump toàn bộ DB từ WordPress' },
			];

			steps.forEach(function (s) {
				setTimeout(function () {
					if (title) title.textContent = s.title;
					if (sub)   sub.textContent   = s.sub;
					setStep(s.step);
				}, s.t);
			});

			var btn = form.querySelector('input[type="submit"]');
			if (btn) btn.disabled = true;
		});
	})();
	</script>
	<?php
}